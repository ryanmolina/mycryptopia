<div class="ec_admin_settings_panel">
	
    <div class="ec_admin_important_numbered_list_fullwidth">
            
        <?php do_action( 'wpeasycart_admin_store_status' ); ?>
            
    </div>
    
</div>