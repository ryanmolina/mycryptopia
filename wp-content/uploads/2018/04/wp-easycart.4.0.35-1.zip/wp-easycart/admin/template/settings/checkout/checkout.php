<div class="ec_admin_settings_panel">
	
    <div class="ec_admin_important_numbered_list">
            
        <?php do_action( 'wpeasycart_admin_checkout_settings' ); ?>
            
    </div>
    
</div>