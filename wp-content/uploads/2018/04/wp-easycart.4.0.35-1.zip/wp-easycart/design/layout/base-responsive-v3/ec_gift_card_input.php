<div class="ec_gift_card_input_row"><?php echo $GLOBALS['language']->get_text( 'quick_view', 'quick_view_gift_card_message' )?></div>
<div class="ec_gift_card_input_row"><?php $this->display_gift_card_message_input_field( ); ?></div>
<div class="ec_gift_card_input_row"><?php echo $GLOBALS['language']->get_text( 'quick_view', 'quick_view_gift_card_to_name' )?></div>
<div class="ec_gift_card_input_row"><?php $this->display_gift_card_to_name_input_field( ); ?></div>
<div class="ec_gift_card_input_row"><?php echo $GLOBALS['language']->get_text( 'quick_view', 'quick_view_gift_card_from_name' )?></div>
<div class="ec_gift_card_input_row"><?php $this->display_gift_card_from_name_input_field( ); ?></div>