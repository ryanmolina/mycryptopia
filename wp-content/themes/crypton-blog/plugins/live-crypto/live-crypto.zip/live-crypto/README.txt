=== Live Crypto ===
Contributors: Happyrobotstudio
Tags: cryptocurrency charts
Requires at least: 3.8.1
Tested up to: 4.2.2
Stable tag: 1.0.4
License: Regular Licence
License URI: https://themeforest.net/licenses/terms/regular


== Description ==

Advanced cryptocurrency charts

== Installation ==

1. Upload to the /wp-content/plugins/ directory or Upload via Plugins menu
2. Activate the plugin through the Plugins menu
3. Click the new 'Live Crypto' button in your wp-admin
4. You are ready !

== Screenshots ==

1. Settings

== Changelog ==


= 1.0 =
Initial
