<?php

/**
 * Provide a view for a section
 *
 * Enter text below to appear below the section title on the Settings page
 *
 * @link       http://happyrobotstudio.com
 * @since      1.0.0
 *
 * @package    Live Crypto
 * @subpackage Live Crypto/admin/partials
 */

?><p></p>
