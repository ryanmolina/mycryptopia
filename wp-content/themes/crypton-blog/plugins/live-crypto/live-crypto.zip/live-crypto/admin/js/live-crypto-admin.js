(function( $ ) {
	'use strict';



      $(document).ready(function() {



		$(window).ready(function() {


		});
	});



	$('body.cryptosymbol_page_live-crypto-importsymbols h1.livecrypto-settings-page-heading').append('<div id="refreshcrypto"><a href="edit.php?post_type=cryptosymbol&page=live-crypto-importsymbols&import=crypto" class="page-title-action">Refresh CRYPTO Symbols</a></div>');





	// // for any metaboxes we create with multiselect, we shall use
	// // https://github.com/nobleclem/jQuery-MultiSelect
	// $('#livecrypto-showonpages').multiselect({ texts: { placeholder: 'All pages' } });
	// $('#livecrypto-showonposts').multiselect({ texts: { placeholder: 'All posts' } });
	// $('#livecrypto-showonpostcategories').multiselect({ texts: { placeholder: 'All categories' } });
	// $('#livecrypto-showonposttags').multiselect({ texts: { placeholder: 'All tags' } });
	//
	//
	//
	// // for any colorpickers, we are using spectrum
	// // https://github.com/bgrins/spectrum
	// $('.colorselector').spectrum( {showInput: true, preferredFormat: "hex" } );








})( jQuery );
