## 1.4.1
* **Fixed:** IE support

## 1.4.0
* **Added:** New feature - Price List!
* **Added:** Translated into two more languages: Germany and French.
* **Fixed:** Minor fixes

## 1.3.2
* **Fixed:** Hotfix. Table styles

## 1.3.1
* **Fixed:** Hotfix. Table disappeared with no column of graph

## 1.3
* **Added:** New awesome admin panel
* **Added:** Localization support
* **Added:** Links to coin pages in the Table
* **Fixed:** Volume 24H data in the Table
* **Fixed:** Change 24H sorting in the Table
* **Fixed:** Table width in desktop
* **Modified:** Parameters "graphColor" and "cursorColor" in the Graph shortcode are depricated (moved to admin panel)
* **Modified:** Converter title name is deleted

## 1.2
* New feature and BugFix! Now you can edit graph color in graph module using two option as graphColor and cursorColor".

## 1.1
* New feature! Now you can add new fields to your converter using parameter "other" into "crtools-converter".

## 1.0.1
* Table module bugFix (pagination, size, etc.)

## 1.0
* Plugin is released. Everything is new!